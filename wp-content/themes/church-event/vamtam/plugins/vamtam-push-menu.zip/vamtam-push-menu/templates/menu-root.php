<nav id="mp-menu" class="mp-menu">
	<%= content %>
</nav>
